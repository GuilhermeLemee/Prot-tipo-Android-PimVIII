package com.example.pimviii_unip

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class activity_alterar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alterar)
    }
}